using System;

namespace Lab4
{
    public static class Lab4A
    {
        private enum Grades
        {
            APlus = 98,
            A = 95,
            AMinus = 92,
            BPlus = 89,
            B = 86,
            BMinus = 83,
            CPlus = 80,
            C = 77,
            CMinus = 74,
            DPlus = 71,
            D = 68,
            DMinus = 65,
            F = 0
        }
        public static void GetGrade()
        {
            try
            {
                Console.Write("Enter the score of your exam: ");
                var score = Math.Round(double.Parse(Console.ReadLine()!));
                var earnedGrade = Grades.F;
                foreach (var grade in Enum.GetValues(typeof(Grades)))
                {
                    if (score < (int) grade) continue;
                    earnedGrade = (Grades) grade;
                }

                var letterGrade = earnedGrade.ToString()
                    .Replace("Plus", "+")
                    .Replace("Minus", "-");

                Console.WriteLine($"Letter grade is: {letterGrade}");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: input must be a numerical value.");
            }
        }
    }
}