using System;
using System.Collections.Generic;

namespace Lab4
{
    public static class Lab4B
    {
        public static void DayMessage()
        {
            List<string> validDays = new()
            {
                "sunday",
                "monday",
                "tuesday",
                "wednesday",
                "thursday",
                "friday",
                "saturday"
            };
            Console.Write("Enter the day: ");
            var day = Console.ReadLine()?.ToLower();
            if (!validDays.Contains(day))
            {
                Console.WriteLine("The day you entered does not exist.");
            }
            else
            {
                string message;
                switch (day)
                {
                    case "monday":
                    case "wednesday":
                        message = "I have class today!";
                        break;
                    case "friday":
                        message = "It’s Friday! Friday! Gotta get down on Friday! ";
                        break;
                    default:
                        message = "I should use this time to do my homework.";
                        break;
                }

                Console.WriteLine(message);
            }
        }
    }
}