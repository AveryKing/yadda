using System;
using System.Collections.Generic;
using System.Linq;
namespace Lab4
{
    public static class Lab4C
    {
        public static void Calculator()
        {
            var validOptions = new Dictionary<int, string>
            {
                {0, "Get the additive inverse of the number"},
                {1, "Get the reciprocal of the number"},
                {2, "Square the number"},
                {3, "Cube the number"},
                {4, "Exit the program"}
            };
            Console.WriteLine("Welcome!");
            Console.Write("Please input a number: ");
            var input = Console.ReadLine();
        
            while (!int.TryParse(input, out var x))
            {
                Console.Write("Please input a number (must be an integer): ");
                input = Console.ReadLine();
            }

            foreach (var (key, value) in validOptions)
            {
                Console.WriteLine($"{key} - {value}");
            }

            Console.Write("What would you like to do to this number?: ");
            var selectedOption = Console.ReadLine();
           
            while (!int.TryParse(selectedOption, out var intSelectedOption) ||
                   !validOptions.Keys.Contains<int>(int.Parse(selectedOption!)))
            {
                Console.WriteLine("The option you selected is invalid.");
                Console.Write("What would you like to do to this number?: ");
                selectedOption = Console.ReadLine();
            }

            switch (int.Parse(selectedOption))
            {
                case 0:
                    GetAdditiveInverse(int.Parse(input));
                    break;
                case 1:
                    GetReciprocal(int.Parse(input));
                    break;
                case 2:
                    SquareNumber(int.Parse(input));
                    break;
                case 3:
                    CubeNumber(int.Parse(input));
                    break;
                case 4:
                    Exit();
                    break;
            }
        }
        public static void GetAdditiveInverse(int number)
        {
            Console.WriteLine($"The additive inverse of {number} is {number * -1}");
            Exit();
        }

        public static void GetReciprocal(int number)
        {
            Console.WriteLine($"The reciprocal of {number} is {1 / number}");
            Exit();
        }

        public static void SquareNumber(int number)
        {
            Console.WriteLine($"The square of {number} is {Math.Pow(number,2)}");
            Exit();
        }

        public static void CubeNumber(int number)
        {
            Console.WriteLine($"The cube of {number} is {Math.Pow(number,3)}");
            Exit();
        }

        public static void Exit()
        {
            Console.WriteLine("Thank you, goodbye!");
            Environment.Exit(0);
        }
    }
}