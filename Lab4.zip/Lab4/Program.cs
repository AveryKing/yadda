﻿using System;
using System.Threading.Channels;

namespace Lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome");
            Console.WriteLine("1 - Lab 4A");
            Console.WriteLine("2 - Lab 4B");
            Console.WriteLine("3 - Lab 4C");
            Console.Write("Please make a selection: ");
            var input = int.Parse(Console.ReadLine()!);
            switch (input)
            {
                case 1:
                    Lab4A.GetGrade();
                    break;
                case 2:
                    Lab4B.DayMessage();
                    break;
                case 3:
                    Lab4C.Calculator();
                    break;
                default:
                    Console.WriteLine("The option you selected is invalid.");
                    break;
            }
        }
    }
}